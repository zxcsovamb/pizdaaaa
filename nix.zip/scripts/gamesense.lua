local var_0_0 = 0
local var_0_1 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 150)
local var_0_2 = 0
local var_0_3 = 60
local var_0_4 = false
local var_0_5 = false
local var_0_6 = "C:/gamesense/skeet1.png"
local var_0_7 = "C:/gamesense/skeet2.png"
local var_0_8 = "C:/gamesense/skeet3.png"
local var_0_9 = "C:/gamesense/skeet4.png"
local var_0_10 = "C:/gamesense/skeet5.png"
local var_0_11 = "C:/gamesense/skeet6.png"
local var_0_12 = "C:/gamesense/skeet7.png"
local var_0_13 = "C:/gamesense/skeet8.png"
local var_0_14 = "C:/gamesense/logo.png"

tab_1 = render.setup_texture(var_0_6)
tab_2 = render.setup_texture(var_0_7)
tab_3 = render.setup_texture(var_0_8)
tab_4 = render.setup_texture(var_0_9)
tab_5 = render.setup_texture(var_0_10)
tab_6 = render.setup_texture(var_0_11)
tab_7 = render.setup_texture(var_0_12)
tab_8 = render.setup_texture(var_0_13)
logo_1337 = render.setup_texture(var_0_14)

local var_0_15 = color_t(1, 1, 1, 1)

local function var_0_16(arg_1_0, arg_1_1, arg_1_2)
	return arg_1_0 + (arg_1_1 - arg_1_0) * arg_1_2
end

local function var_0_17()
	var_0_2 = var_0_2 + 0.5

	if var_0_2 < var_0_3 then
		var_0_0 = var_0_16(var_0_0, 1, 0.05)
	else
		if not var_0_4 then
			var_0_4 = true
		end

		var_0_0 = var_0_16(var_0_0, 0, 0.05)
	end

	if var_0_4 and var_0_0 <= 0.01 then
		var_0_5 = true
	end
end

local function var_0_18()
	local var_3_0 = (render.screen_size() - render.calc_text_size("RAZECLUB", var_0_1)) / 2

	render.text("RAZECLUB", var_0_1, var_3_0, color_t(1, 1, 1, var_0_0))
end

local var_0_19 = {}
local var_0_20 = 0.9
local var_0_21 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 12.4 * var_0_20)
local var_0_22 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 14.4 * var_0_20)
local var_0_23 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 14 * var_0_20)
local var_0_24 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 13 * var_0_20)
local var_0_25 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 28 * var_0_20)
local var_0_26 = render.setup_font("C:/Windows/Fonts/verdanab.ttf", 13 * var_0_20)
local var_0_27 = render.setup_font("C:/Windows/Fonts/verdanab.ttf", 18 * var_0_20)
local var_0_28 = render.setup_font("C:/Windows/Fonts/verdanab.ttf", 27 * var_0_20)
local var_0_29 = render.setup_font("C:/gamesense/font_0.ttf", 44 * var_0_20)
local var_0_30 = render.setup_font("C:/gamesense/font_0.ttf", 60 * var_0_20)
local var_0_31 = render.setup_font("C:/gamesense/font_0.ttf", 54 * var_0_20)
local var_0_32 = render.setup_font("C:/gamesense/font_0.ttf", 53 * var_0_20)
local var_0_33 = render.setup_font("C:/gamesense/font_0.ttf", 47 * var_0_20)

local function var_0_34(arg_4_0, arg_4_1, arg_4_2, arg_4_3, arg_4_4, arg_4_5, arg_4_6)
	local var_4_0 = {
		type = nil,
		maxValue = nil,
		minValue = nil,
		value = nil,
		increment = nil,
		text = nil,
		name = nil,
		type = arg_4_0,
		name = arg_4_1,
		value = arg_4_2,
		minValue = arg_4_3,
		maxValue = arg_4_4,
		increment = arg_4_5,
		text = arg_4_6
	}

	table.insert(var_0_19, var_4_0)

	return var_4_0
end

local function var_0_35(arg_5_0, arg_5_1)
	return var_0_34("booleanFirst", arg_5_0, arg_5_1)
end

local function var_0_36(arg_6_0, arg_6_1)
	return var_0_34("boolean", arg_6_0, arg_6_1)
end

local function var_0_37(arg_7_0, arg_7_1)
	return var_0_34("boolean2", arg_7_0, arg_7_1)
end

local function var_0_38(arg_8_0, arg_8_1)
	return var_0_34("boolean2_vac", arg_8_0, arg_8_1)
end

local function var_0_39(arg_9_0, arg_9_1, arg_9_2, arg_9_3, arg_9_4)
	return var_0_34("int", arg_9_0, arg_9_1, arg_9_2, arg_9_3, arg_9_4)
end

local function var_0_40(arg_10_0, arg_10_1, arg_10_2, arg_10_3, arg_10_4)
	return var_0_34("int2", arg_10_0, arg_10_1, arg_10_2, arg_10_3, arg_10_4)
end

local function var_0_41(arg_11_0)
	return var_0_34("text", nil, nil, nil, nil, nil, arg_11_0)
end

local var_0_42 = var_0_34("color", "Menu Color", color_t(1, 1, 1, 0.9))
local var_0_43 = var_0_35("RAZE CLUB", true)
local var_0_44 = var_0_36("Manual AA", false)
local var_0_45 = var_0_36("Show FPS and Ping on head", false)
local var_0_46 = var_0_36("Hit log", false)
local var_0_47 = var_0_36("Hit log center", false)
local var_0_48 = var_0_36("Auto buy", false)
local var_0_49 = var_0_36("Custom Scope", false)
local var_0_50 = var_0_39("Offset", 10, -100, 100, 1)
local var_0_51 = var_0_39("Length", 100, -100, 100, 1)
local var_0_52 = var_0_39("Scope transparency", 1, 0, 1, 0.1)
local var_0_53 = var_0_39("FOV", 90, 1, 150, 1)
local var_0_54 = var_0_39("Thirdperson Distance", 100, 1, 150, 1)
local var_0_55 = var_0_37("Watermark", true)
local var_0_56 = var_0_37("Trashtalk", false)
local var_0_57 = var_0_37("Indicators", false)
local var_0_58 = var_0_37("Snow in World", false)
local var_0_59 = var_0_37("Snow in Menu", false)
local var_0_60 = var_0_38("Preserve killfeed (VAC)", false)
local var_0_61 = var_0_37("Vamp gamesense theme", false)
local var_0_62 = {
	y = nil,
	x = nil,
	tabAlpha = 1,
	currentTab = "rage",
	isTypingWidth = false,
	alpha = 1,
	targetHeight = 560,
	targetWidth = 660,
	dragOffset = nil,
	isDragging = false,
	isOpen = true,
	height = 560,
	width = 660,
	x = 5 * var_0_20,
	y = 5 * var_0_20,
	dragOffset = {
		y = 0,
		x = 0
	}
}
local var_0_63 = color_t(0.624, 0.792, 0.169, var_0_62.alpha)

local function var_0_64(arg_12_0, arg_12_1)
	local var_12_0 = math.floor(arg_12_0 / arg_12_1)

	return arg_12_1 * (var_12_0 + (arg_12_0 / arg_12_1 - var_12_0 > 0.5 and 1 or 0))
end

ffi.cdef("    typedef struct {\n        long x;\n        long y;\n    } POINT;\n\n    int GetCursorPos(POINT* lpPoint);\n    int ScreenToClient(void* hWnd, POINT* lpPoint);\n    short GetAsyncKeyState(int vKey);\n    void* GetForegroundWindow();\n    unsigned long GetTickCount();\n\n    static const int VK_INSERT = 0x2D;\n    static const int VK_LBUTTON = 0x01;\n    static const int VK_UP = 0x26;\n    static const int VK_DOWN = 0x28;\n    static const int VK_PRIOR = 0x21;\n    static const int VK_NEXT = 0x22;\n")

local var_0_65 = ffi.load("user32")
local var_0_66 = ffi.load("kernel32")
local var_0_67 = {
	UP = 38,
	LBUTTON = 1,
	INSERT = 45,
	NEXT = 34,
	PRIOR = 33,
	DOWN = 40
}
local var_0_68 = {
	mouse = false,
	insert = false
}

local function var_0_69()
	local var_13_0 = ffi.new("POINT[1]")

	var_0_65.GetCursorPos(var_13_0)
	var_0_65.ScreenToClient(var_0_65.GetForegroundWindow(), var_13_0)

	return vec2_t(var_13_0[0].x, var_13_0[0].y)
end

local function var_0_70(arg_14_0, arg_14_1, arg_14_2)
	return arg_14_0 + (arg_14_1 - arg_14_0) * arg_14_2
end

local function var_0_71(arg_15_0, arg_15_1, arg_15_2)
	return math.max(arg_15_1, math.min(arg_15_0, arg_15_2))
end

local function var_0_72(arg_16_0)
	return bit.band(var_0_65.GetAsyncKeyState(arg_16_0), 32768) ~= 0
end

local function var_0_73(arg_17_0)
	if not var_0_62.isTypingWidth then
		return
	end

	for iter_17_0 = 48, 57 do
		if var_0_72(iter_17_0) and not var_0_68[iter_17_0] then
			arg_17_0.value = arg_17_0.value .. string.char(iter_17_0)
		end

		var_0_68[iter_17_0] = var_0_72(iter_17_0)
	end

	if var_0_72(8) and not var_0_68[8] then
		arg_17_0.value = arg_17_0.value:sub(1, -2)
	end

	var_0_68[8] = var_0_72(8)

	if var_0_72(13) and not var_0_68[13] then
		local var_17_0 = tonumber(arg_17_0.value)

		if var_17_0 and var_17_0 >= 350 and var_17_0 <= 670 then
			var_0_62.targetWidth = var_17_0
		end

		var_0_62.isTypingWidth = false
	end

	var_0_68[13] = var_0_72(13)
end

local var_0_74 = {
	purple_neon = nil,
	accent = nil,
	shadow_color = nil,
	border_color = nil,
	glass_color = nil,
	accent = color_t(0.8, 1, 0.2588, 1),
	purple_neon = color_t(0.7, 0.2, 1, 1),
	glass_color = color_t(0.1, 0.1, 0.1, 0.7),
	border_color = color_t(1, 1, 1, 0.2),
	shadow_color = color_t(0, 0, 0, 0.5)
}
local var_0_75 = render.setup_font("C:/Windows/Fonts/verdanab.ttf", 12, 16)
local var_0_76 = 0
local var_0_77 = 0
local var_0_78 = os.clock()

local function var_0_79()
	if os.clock() - var_0_78 >= 1 then
		var_0_77 = var_0_76
		var_0_76 = 0
		var_0_78 = os.clock()
	end
end

local function var_0_80()
	if not var_0_55.value then
		return
	end

	local var_19_0 = render.screen_size()
	local var_19_1 = os.date("%H:%M")
	local var_19_2 = string.format("GAME             | Time: %s", var_19_1)
	local var_19_3 = render.calc_text_size(var_19_2, var_0_75)
	local var_19_4 = 3
	local var_19_5 = 1070
	local var_19_6 = 0

	render.rect_filled(vec2_t(var_19_5 + 686, var_19_6 + 6), vec2_t(var_19_5 + var_19_3.x + 701, var_19_6 + var_19_3.y + 24), color_t(0.2, 0.2, 0.2, 255), 0)
	render.rect_filled(vec2_t(var_19_5 + 690, var_19_6 + 10), vec2_t(var_19_5 + var_19_3.x + 697, var_19_6 + var_19_3.y + 20), color_t(0.1, 0.1, 0.1, 255), 0)
	render.line(vec2_t(var_19_5 + 688, var_19_6 + 8), vec2_t(var_19_5 + var_19_3.x + 699, var_19_6 + 8), color_t(0.1, 0.1, 0.1, 255))
	render.line(vec2_t(var_19_5 + 688, var_19_6 + 8), vec2_t(var_19_5 + 688, var_19_6 + 33), color_t(0.1, 0.1, 0.1, 255))
	render.line(vec2_t(var_19_5 + 688, var_19_6 + 33), vec2_t(var_19_5 + var_19_3.x + 699, var_19_6 + 33), color_t(0.1, 0.1, 0.1, 255))
	render.line(vec2_t(var_19_5 + var_19_3.x + 698, var_19_6 + 8), vec2_t(var_19_5 + var_19_3.x + 698, var_19_6 + 33), color_t(0.1, 0.1, 0.1, 255))

	local var_19_7 = var_19_5 + 690 + var_19_4
	local var_19_8 = var_19_6 + var_19_4 + 10

	render.text(var_19_2, var_0_75, vec2_t(var_19_7, var_19_8 + 2), color_t(1, 1, 1, 1))
	render.text("SENSE", var_0_75, vec2_t(var_19_7 + 33, var_19_8 + 2), color_t(0.4, 0.8, 0.4, 1))
end

local var_0_81 = {
	"YOU ARE A...VAMP ?",
	"Own3d by gamesense.lua.",
	"t.me/razeclub - stay vamps.",
	"Бро, ты упал почему падаешь ? Прикупи gamesense.lua",
	"Мертвая бабка и то лучше отыгрывает.",
	"Шлюха, ливни с хвх, ты не сабнут на рейза и у тебя нет gamesense.lua",
	"Мтомото трахнуло твой рото",
	"Вакуум отьебал твою узкую уздечку",
	"1 сын нищей шлюхи",
	"Соси мой пенис гандурас ты без gamesense.lua",
	"gamesense.lua выебал твой рот ведь ты лысый идиот",
	"Gamesense.lua трахнула твой рот по Bluetooth"
}
local var_0_82 = 0

register_callback("player_death", function(arg_20_0)
	if var_0_56.value and arg_20_0:get_pawn("attacker") == entitylist.get_local_player_pawn() then
		engine.execute_client_cmd("say " .. var_0_81[var_0_82 % #var_0_81 + 1])

		var_0_82 = var_0_82 + 1
	end
end)

local var_0_83 = "buy ssg08;buy deagle"

register_callback("round_start", function()
	if var_0_48.value then
		engine.execute_client_cmd(var_0_83)
	end
end)

local function var_0_84()
	local var_22_0 = var_0_72(var_0_67.INSERT)

	if var_22_0 and not var_0_68.insert then
		var_0_62.isOpen = not var_0_62.isOpen
	end

	var_0_68.insert = var_22_0
	var_0_62.alpha = var_0_70(var_0_62.alpha, var_0_62.isOpen and 1 or 0, render.frame_time() * 10)

	if var_0_62.alpha <= 0 then
		return
	end

	local var_22_1 = {
		click = false,
		down = nil,
		pos = nil,
		pos = var_0_69(),
		down = var_0_72(var_0_67.LBUTTON)
	}

	var_22_1.click = var_22_1.down and not var_0_68.mouse

	local var_22_2 = false

	if var_0_62.currentTab == "main" then
		local var_22_3 = var_0_62.y + 80 * var_0_20

		for iter_22_0, iter_22_1 in ipairs(var_0_19) do
			if iter_22_1.type == "int" then
				local var_22_4 = var_0_62.x + var_0_62.width - 180 * var_0_20 - 5 * var_0_20
				local var_22_5 = var_22_3
				local var_22_6 = 225 * var_0_20

				if var_22_4 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_4 + var_22_6 and var_22_5 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_5 + 25 * var_0_20 then
					var_22_2 = true

					if var_22_1.down then
						local var_22_7 = var_0_71((var_22_1.pos.x - var_22_4) / var_22_6, 0, 1)

						iter_22_1.value = var_0_64(var_0_70(iter_22_1.minValue, iter_22_1.maxValue, var_22_7), iter_22_1.increment)
					end
				end
			end

			var_22_3 = var_22_3 + 35 * var_0_20
		end
	end

	if var_22_1.click and not var_22_2 and var_22_1.pos.x >= var_0_62.x and var_22_1.pos.x <= var_0_62.x + var_0_62.width and var_22_1.pos.y >= var_0_62.y and var_22_1.pos.y <= var_0_62.y + var_0_62.height then
		var_0_62.isDragging = true
		var_0_62.dragOffset.x = var_22_1.pos.x - var_0_62.x
		var_0_62.dragOffset.y = var_22_1.pos.y - var_0_62.y
	end

	if not var_22_1.down then
		var_0_62.isDragging = false
	end

	if var_0_62.isDragging then
		var_0_62.x = var_22_1.pos.x - var_0_62.dragOffset.x
		var_0_62.y = var_22_1.pos.y - var_0_62.dragOffset.y
	end

	var_0_68.mouse = var_22_1.down
	var_0_62.width = var_0_70(var_0_62.width, var_0_62.targetWidth, render.frame_time() * 10)
	var_0_62.height = var_0_70(var_0_62.height, var_0_62.targetHeight, render.frame_time() * 10)

	local var_22_8 = color_t(1, 1, 1, 1)
	local var_22_9 = os.clock() * 2
	local var_22_10 = math.sin(var_22_9) * 0.5 + 0.5
	local var_22_11 = math.sin(var_22_9 + 2) * 0.5 + 0.5
	local var_22_12 = math.sin(var_22_9 + 4) * 0.5 + 0.5
	local var_22_13 = color_t(var_22_10, var_22_11, var_22_12, var_0_62.alpha)
	local var_22_14
	local var_22_15
	local var_22_16
	local var_22_17
	local var_22_18
	local var_22_19 = color_t(1, 1, 1, 1)
	local var_22_20 = color_t(0, 0, 0, 1)
	local var_22_21 = color_t(0.2, 0.2, 0.2, 1)
	local var_22_22 = color_t(0.2, 0.2, 0.2, 1)

	if var_0_61.value then
		var_0_63 = color_t(0.7, 0.7, 0.7, var_0_62.alpha)
	else
		var_0_63 = color_t(0.624, 0.792, 0.169, var_0_62.alpha)
	end

	if not var_0_43.value then
		os.execute("start " .. "https://t.me/raze_club")

		var_0_43.value = true
	end

	if var_0_62.currentTab == "rage" then
		render.texture(tab_1, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
		render.text("General", var_0_26, vec2_t(var_0_62.x + 116, var_0_62.y + 96), color_t(1, 1, 1, var_0_62.alpha))
		render.text("RAZECLUB", var_0_26, vec2_t(var_0_62.x + 116, var_0_62.y + 26), color_t(1, 1, 1, var_0_62.alpha))
		render.text("Other", var_0_26, vec2_t(var_0_62.x + 392, var_0_62.y + 26), color_t(1, 1, 1, var_0_62.alpha))
		render.texture(logo_1337, vec2_t(var_0_62.x + 301, var_0_62.y + 32), vec2_t(var_0_62.x + 346, var_0_62.y + 76), color_t(1, 1, 1, 0.5 * var_0_62.alpha))
	end

	if var_0_62.currentTab == "antiaim" then
		render.texture(tab_2, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	if var_0_62.currentTab == "legit" then
		render.texture(tab_3, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	if var_0_62.currentTab == "visuals" then
		render.texture(tab_4, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	if var_0_62.currentTab == "misc" then
		render.texture(tab_5, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	if var_0_62.currentTab == "skins" then
		render.texture(tab_6, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	if var_0_62.currentTab == "profile" then
		render.texture(tab_7, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	if var_0_62.currentTab == "configs" then
		render.texture(tab_8, vec2_t(var_0_62.x, var_0_62.y), vec2_t(var_0_62.x + var_0_62.width, var_0_62.y + var_0_62.height), color_t(1, 1, 1, var_0_62.alpha))
	end

	local var_22_23 = 86 * var_0_20
	local var_22_24 = 62 * var_0_20
	local var_22_25 = var_0_62.x + 5 * var_0_20
	local var_22_26 = var_0_62.y + 22 * var_0_20

	if var_22_1.click then
		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_26 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_26 + var_22_24 then
			var_0_62.currentTab = "rage"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 70 and var_22_1.pos.y <= var_22_26 + var_22_24 + 75 then
			var_0_62.currentTab = "antiaim"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 140 and var_22_1.pos.y <= var_22_26 + var_22_24 + 130 then
			var_0_62.currentTab = "legit"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 200 and var_22_1.pos.y <= var_22_26 + var_22_24 + 200 then
			var_0_62.currentTab = "visuals"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 270 and var_22_1.pos.y <= var_22_26 + var_22_24 + 270 then
			var_0_62.currentTab = "misc"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 320 and var_22_1.pos.y <= var_22_26 + var_22_24 + 320 then
			var_0_62.currentTab = "skins"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 390 and var_22_1.pos.y <= var_22_26 + var_22_24 + 390 then
			var_0_62.currentTab = "profile"
		end

		if var_22_25 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_25 + var_22_23 and var_22_1.pos.y >= var_22_26 + 460 and var_22_1.pos.y <= var_22_26 + var_22_24 + 460 then
			var_0_62.currentTab = "configs"
		end
	end

	var_0_62.tabAlpha = var_0_70(var_0_62.tabAlpha, var_0_62.currentTab == "rage" and 1 or 0, render.frame_time() * 10)

	if var_0_62.currentTab == "rage" then
		local var_22_27 = var_0_62.y + 109 * var_0_20

		for iter_22_2, iter_22_3 in ipairs(var_0_19) do
			if iter_22_3.type == "text" then
				render.text(iter_22_3.text, var_0_23, vec2_t(var_0_62.x + 10 * var_0_20, var_22_27), var_22_15:lerp(color_t(0, 0, 0, 0), 1 - var_0_62.alpha))

				if iter_22_3.name == "Menu Width" then
					local var_22_28 = var_0_62.x + var_0_62.width - 180 * var_0_20 - 5 * var_0_20
					local var_22_29 = var_22_27

					render.rect_filled(vec2_t(var_22_28, var_22_29), vec2_t(var_22_28 + 165 * var_0_20, var_22_29 + 15 * var_0_20), color_t(0.8, 0.8, 0.8, var_0_62.alpha), 4 * var_0_20)

					local var_22_30 = var_22_15

					render.text(iter_22_3.value, var_0_23, vec2_t(var_22_28 + 5 * var_0_20, var_22_29), var_22_30:lerp(color_t(0, 0, 0, 0)))

					if var_22_1.click and var_22_28 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_28 + 165 * var_0_20 and var_22_29 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_29 + 15 * var_0_20 then
						var_0_62.isTypingWidth = true
					end
				end
			elseif iter_22_3.type == "boolean" then
				render.text(iter_22_3.name, var_0_22, vec2_t(var_0_62.x + 159 * var_0_20, var_22_27 - 13), color_t(1, 1, 1, var_0_62.alpha))

				local var_22_31 = var_0_62.x + 139 * var_0_20 - 1 * var_0_20
				local var_22_32 = var_22_27 - 12
				local var_22_33 = iter_22_3.value and var_0_63 or color_t(0.4, 0.4, 0.4, var_0_62.alpha)

				render.rect_filled(vec2_t(var_22_31 + 0.5, var_22_32 + 0.5), vec2_t(var_22_31 + 7.5 * var_0_20, var_22_32 + 7.5 * var_0_20), var_22_33:lerp(color_t(0, 0, 0, 0)))
				render.rect(vec2_t(var_22_31, var_22_32), vec2_t(var_22_31 + 8 * var_0_20, var_22_32 + 8 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))

				if var_22_1.click and var_22_31 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_31 + 15 * var_0_20 and var_22_32 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_32 + 15 * var_0_20 then
					iter_22_3.value = not iter_22_3.value
				end
			elseif iter_22_3.type == "boolean2" then
				render.text(iter_22_3.name, var_0_22, vec2_t(var_0_62.x + 467 * var_0_20, var_22_27 - 352), color_t(1, 1, 1, var_0_62.alpha))

				local var_22_34 = var_0_62.x + 447 * var_0_20 - 1 * var_0_20
				local var_22_35 = var_22_27 - 350
				local var_22_36 = iter_22_3.value and var_0_63 or color_t(0.4, 0.4, 0.4, var_0_62.alpha)

				render.rect_filled(vec2_t(var_22_34 + 0.5, var_22_35 + 0.5), vec2_t(var_22_34 + 7.5 * var_0_20, var_22_35 + 7.5 * var_0_20), var_22_36:lerp(color_t(0, 0, 0, 0)))
				render.rect(vec2_t(var_22_34, var_22_35), vec2_t(var_22_34 + 8 * var_0_20, var_22_35 + 8 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))

				if var_22_1.click and var_22_34 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_34 + 15 * var_0_20 and var_22_35 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_35 + 15 * var_0_20 then
					iter_22_3.value = not iter_22_3.value
				end
			elseif iter_22_3.type == "boolean2_vac" then
				render.text(iter_22_3.name, var_0_22, vec2_t(var_0_62.x + 467 * var_0_20, var_22_27 - 352), color_t(0.792, 0.725, 0.29, var_0_62.alpha))

				local var_22_37 = var_0_62.x + 447 * var_0_20 - 1 * var_0_20
				local var_22_38 = var_22_27 - 350
				local var_22_39 = iter_22_3.value and var_0_63 or color_t(0.4, 0.4, 0.4, var_0_62.alpha)

				render.rect_filled(vec2_t(var_22_37 + 0.5, var_22_38 + 0.5), vec2_t(var_22_37 + 7.5 * var_0_20, var_22_38 + 7.5 * var_0_20), var_22_39:lerp(color_t(0, 0, 0, 0)))
				render.rect(vec2_t(var_22_37, var_22_38), vec2_t(var_22_37 + 8 * var_0_20, var_22_38 + 8 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))

				if var_22_1.click and var_22_37 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_37 + 15 * var_0_20 and var_22_38 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_38 + 15 * var_0_20 then
					iter_22_3.value = not iter_22_3.value
				end
			elseif iter_22_3.type == "booleanFirst" then
				render.text(iter_22_3.name, var_0_22, vec2_t(var_0_62.x + 159 * var_0_20, var_22_27 - 67), color_t(1, 1, 1, var_0_62.alpha))

				local var_22_40 = var_0_62.x + 139 * var_0_20 - 1 * var_0_20
				local var_22_41 = var_22_27 - 65
				local var_22_42 = iter_22_3.value and var_0_63 or color_t(0.4, 0.4, 0.4, var_0_62.alpha)

				render.rect_filled(vec2_t(var_22_40 + 0.5, var_22_41 + 0.5), vec2_t(var_22_40 + 7.5 * var_0_20, var_22_41 + 7.5 * var_0_20), var_22_42:lerp(color_t(0, 0, 0, 0)))
				render.rect(vec2_t(var_22_40, var_22_41), vec2_t(var_22_40 + 8 * var_0_20, var_22_41 + 8 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))

				if var_22_1.click and var_22_40 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_40 + 15 * var_0_20 and var_22_41 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_41 + 15 * var_0_20 then
					iter_22_3.value = not iter_22_3.value
				end
			elseif iter_22_3.type == "int" then
				local var_22_43 = var_0_62.x + 165 * var_0_20 - 5 * var_0_20
				local var_22_44 = var_22_27 - 5
				local var_22_45 = 175 * var_0_20

				render.text(iter_22_3.name, var_0_22, vec2_t(var_0_62.x + 160 * var_0_20, var_22_44 - 10), color_t(1, 1, 1, var_0_62.alpha))

				if var_22_43 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_43 + var_22_45 and var_22_44 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_44 + 15 * var_0_20 then
					local var_22_46 = true

					if var_22_1.down then
						local var_22_47 = var_0_71((var_22_1.pos.x - var_22_43) / var_22_45, 0, 1)

						iter_22_3.value = var_0_64(var_0_70(iter_22_3.minValue, iter_22_3.maxValue, var_22_47), iter_22_3.increment)
					end
				end

				local var_22_48 = (iter_22_3.value - iter_22_3.minValue) / (iter_22_3.maxValue - iter_22_3.minValue)
				local var_22_49 = var_0_71(var_22_48 * 2, 0, 1)
				local var_22_50 = color_t(var_0_70(1, 0, var_22_49), var_0_70(1, 0, var_22_49), var_0_70(1, 0, var_22_49), 1)
				local var_22_51 = color_t(0.1, 0.1, 0.1, 1)

				render.rect_filled(vec2_t(var_22_43, var_22_44 + 6), vec2_t(var_22_43 + var_22_45, var_22_44 + 15 * var_0_20), color_t(0.2, 0.2, 0.2, var_0_62.alpha))
				render.rect(vec2_t(var_22_43, var_22_44 + 6), vec2_t(var_22_43 + var_22_45, var_22_44 + 15 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))
				render.rect_filled(vec2_t(var_22_43, var_22_44 + 7.5), vec2_t(var_22_43 + var_22_45 * var_22_48, var_22_44 + 13.5 * var_0_20), var_0_63)

				local var_22_52 = tostring(iter_22_3.value) .. "%"

				render.text(var_22_52, var_0_26, vec2_t(var_22_43 + var_22_45 * var_22_48 - 13, var_22_44 + 8 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))
				render.text(var_22_52, var_0_24, vec2_t(var_22_43 + var_22_45 * var_22_48 - 12, var_22_44 + 8 * var_0_20), color_t(1, 1, 1, var_0_62.alpha))

				var_22_27 = var_22_27 + 11 * var_0_20
			elseif iter_22_3.type == "int2" then
				local var_22_53 = var_0_62.x + 482 * var_0_20 - 5 * var_0_20
				local var_22_54 = var_22_27 - 265
				local var_22_55 = 175 * var_0_20

				render.text(iter_22_3.name, var_0_22, vec2_t(var_0_62.x + 477 * var_0_20, var_22_54 - 10), color_t(1, 1, 1, var_0_62.alpha))

				if var_22_53 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_53 + var_22_55 and var_22_54 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_54 + 15 * var_0_20 then
					local var_22_56 = true

					if var_22_1.down then
						local var_22_57 = var_0_71((var_22_1.pos.x - var_22_53) / var_22_55, 0, 1)

						iter_22_3.value = var_0_64(var_0_70(iter_22_3.minValue, iter_22_3.maxValue, var_22_57), iter_22_3.increment)
					end
				end

				local var_22_58 = (iter_22_3.value - iter_22_3.minValue) / (iter_22_3.maxValue - iter_22_3.minValue)
				local var_22_59 = var_0_71(var_22_58 * 2, 0, 1)
				local var_22_60 = color_t(var_0_70(1, 0, var_22_59), var_0_70(1, 0, var_22_59), var_0_70(1, 0, var_22_59), 1)
				local var_22_61 = color_t(0.1, 0.1, 0.1, 1)

				render.rect_filled(vec2_t(var_22_53, var_22_54 + 6), vec2_t(var_22_53 + var_22_55, var_22_54 + 17 * var_0_20), color_t(0.2, 0.2, 0.2, var_0_62.alpha))
				render.rect(vec2_t(var_22_53, var_22_54 + 6), vec2_t(var_22_53 + var_22_55, var_22_54 + 17 * var_0_20), color_t(0, 0, 0, var_0_62.alpha))
				render.rect_filled(vec2_t(var_22_53, var_22_54 + 7), vec2_t(var_22_53 + var_22_55 * var_22_58, var_22_54 + 16 * var_0_20), var_0_63)

				local var_22_62 = tostring(iter_22_3.value) .. "%"

				render.text(var_22_62, var_0_23, vec2_t(var_22_53 + var_22_55 * var_22_58 - 12, var_22_54 + 8 * var_0_20), color_t(1, 1, 1, var_0_62.alpha))

				var_22_27 = var_22_27 + 11 * var_0_20
			elseif iter_22_3.type == "list" then
				render.text(iter_22_3.name, var_0_23, vec2_t(var_0_62.x + 10 * var_0_20, var_22_27), var_22_15:lerp(color_t(0, 0, 0, 0), 1 - var_0_62.alpha))

				local var_22_63 = var_0_62.x + var_0_62.width - 180 * var_0_20 - 5 * var_0_20
				local var_22_64 = var_22_27

				render.rect_filled(vec2_t(var_22_63, var_22_64), vec2_t(var_22_63 + 165 * var_0_20, var_22_64 + 15 * var_0_20), color_t(0.8, 0.8, 0.8, var_0_62.alpha), 4 * var_0_20)

				local var_22_65 = var_22_15

				render.text(iter_22_3.value, var_0_23, vec2_t(var_22_63 + 5 * var_0_20, var_22_64), var_22_65:lerp(color_t(0, 0, 0, 0), 1 - var_0_62.alpha))

				if var_22_1.click and var_22_63 <= var_22_1.pos.x and var_22_1.pos.x <= var_22_63 + 165 * var_0_20 and var_22_64 <= var_22_1.pos.y and var_22_1.pos.y <= var_22_64 + 15 * var_0_20 then
					local var_22_66 = 1

					for iter_22_4, iter_22_5 in ipairs(iter_22_3.options) do
						if iter_22_5 == iter_22_3.value then
							var_22_66 = iter_22_4

							break
						end
					end

					iter_22_3.value = iter_22_3.options[var_22_66 % #iter_22_3.options + 1]
				end
			end

			var_22_27 = var_22_27 + 22 * var_0_20
		end
	elseif var_0_62.currentTab == "antiaim" then
		-- block empty
	end

	var_0_80()
end

register_callback("paint", function()
	if not var_0_5 then
		var_0_17()
		var_0_18()
	else
		var_0_84()
	end
end)

local var_0_85 = {}
local var_0_86 = 100
local var_0_87 = 2
local var_0_88 = 0.1
local var_0_89 = 0.05
local var_0_90 = 0.1
local var_0_91 = 0
local var_0_92 = 1000
local var_0_93 = 200
local var_0_94 = 500
local var_0_95 = false

local function var_0_96(arg_24_0)
	if #var_0_85 >= var_0_86 then
		return
	end

	local var_24_0 = math.random() * 2 * math.pi
	local var_24_1 = math.random() * var_0_94
	local var_24_2 = {
		velocity = nil,
		size = nil,
		position = nil,
		position = {
			y = nil,
			x = nil,
			z = nil,
			x = arg_24_0.x + var_24_1 * math.cos(var_24_0),
			y = arg_24_0.y + var_24_1 * math.sin(var_24_0),
			z = arg_24_0.z + var_0_92
		},
		velocity = {
			y = nil,
			x = nil,
			z = nil,
			x = math.random(-1, 1) * var_0_89,
			y = math.random(-1, 1) * var_0_89,
			z = -math.random(1, 3)
		},
		size = var_0_87
	}

	table.insert(var_0_85, var_24_2)
end

local function var_0_97(arg_25_0)
	if arg_25_0 == nil then
		print("Ошибка: позиция игрока не определена.")

		return
	end

	local var_25_0 = render.frame_time()

	var_0_91 = var_0_91 + var_25_0

	if 1 / var_25_0 < 45 then
		var_0_95 = true
	else
		var_0_95 = false
	end

	if not var_0_95 and #var_0_85 < var_0_86 and var_0_91 >= var_0_90 then
		var_0_96(arg_25_0)

		var_0_91 = 0
	end

	if not var_0_95 then
		for iter_25_0 = #var_0_85, 1, -1 do
			local var_25_1 = var_0_85[iter_25_0]

			var_25_1.velocity.z = var_25_1.velocity.z - var_0_88 * var_25_0
			var_25_1.position.x = var_25_1.position.x + var_25_1.velocity.x
			var_25_1.position.y = var_25_1.position.y + var_25_1.velocity.y
			var_25_1.position.z = var_25_1.position.z + var_25_1.velocity.z

			if var_25_1.position.z < arg_25_0.z - var_0_93 then
				local var_25_2 = math.random() * 2 * math.pi
				local var_25_3 = math.random() * var_0_94

				var_25_1.position.z = arg_25_0.z + var_0_92
				var_25_1.position.x = arg_25_0.x + var_25_3 * math.cos(var_25_2)
				var_25_1.position.y = arg_25_0.y + var_25_3 * math.sin(var_25_2)
			end
		end
	end
end

local function var_0_98(arg_26_0)
	for iter_26_0, iter_26_1 in ipairs(var_0_85) do
		local var_26_0 = render.world_to_screen(vec3_t(iter_26_1.position.x, iter_26_1.position.y, iter_26_1.position.z))

		if var_26_0 ~= nil then
			local var_26_1 = math.abs(iter_26_1.position.z - arg_26_0.z)
			local var_26_2 = var_0_87 * (1 - var_26_1 / var_0_92)
			local var_26_3 = math.max(1, var_26_2)

			render.circle_filled(var_26_0, var_26_3, 12, color_t(255, 255, 255, 255))
		end
	end
end

register_callback("paint", function()
	if not var_0_58.value then
		return
	end

	local var_27_0 = entitylist.get_local_player_pawn()

	if var_27_0 == nil then
		print("Ошибка: игрок не найден.")

		return
	end

	local var_27_1 = var_27_0.m_pGameSceneNode

	if var_27_1 == nil then
		print("Ошибка: CGameSceneNode не найден.")

		return
	end

	local var_27_2 = var_27_1.m_vecAbsOrigin

	if var_27_2 == nil then
		print("Ошибка: позиция игрока (m_vecAbsOrigin) не определена.")

		return
	end

	var_0_97(var_27_2)
	var_0_98(var_27_2)
end)

local var_0_99 = {}
local var_0_100 = 300
local var_0_101 = 2
local var_0_102 = 0.1
local var_0_103 = 0.05
local var_0_104 = 0.1
local var_0_105 = 0
local var_0_106 = false
local var_0_107 = false

local function var_0_108()
	local var_28_0 = {
		y = nil,
		x = nil,
		speed = nil,
		sway = nil,
		x = math.random(0, render.screen_size().x),
		y = -var_0_101,
		speed = math.random(1, 3),
		sway = math.random(-1, 1) * 0.1
	}

	table.insert(var_0_99, var_28_0)
end

local function var_0_109()
	local var_29_0 = render.frame_time()

	var_0_105 = var_0_105 + var_29_0

	if #var_0_99 < var_0_100 and var_0_105 >= var_0_104 then
		var_0_108()

		var_0_105 = 0
	end

	for iter_29_0 = #var_0_99, 1, -1 do
		local var_29_1 = var_0_99[iter_29_0]

		var_29_1.y = var_29_1.y + var_29_1.speed
		var_29_1.x = var_29_1.x + var_29_1.sway + var_0_103

		if var_29_1.y > render.screen_size().y then
			table.remove(var_0_99, iter_29_0)
		end
	end
end

local function var_0_110()
	for iter_30_0, iter_30_1 in ipairs(var_0_99) do
		render.circle_filled(vec2_t(iter_30_1.x, iter_30_1.y), var_0_101, 10, color_t(255, 255, 255, 255))
	end
end

register_callback("paint", function()
	local var_31_0 = var_0_72(var_0_67.INSERT)

	if var_31_0 and not var_0_68.insert then
		if not var_0_106 then
			var_0_106 = true
			var_0_62.isOpen = not var_0_62.isOpen
		else
			var_0_62.isOpen = not var_0_62.isOpen
		end
	end

	if var_31_0 and not var_0_68.insert then
		if not var_0_107 then
			var_0_107 = true

			print("First press ignored for function")
		else
			var_0_59.value = not var_0_59.value

			if var_0_59.value then
				print("Snow in Menu enabled")
			else
				print("Snow in Menu disabled")
			end
		end
	end

	var_0_68.insert = var_31_0

	if var_0_62.isOpen and var_0_59.value then
		var_0_109()
		var_0_110()
	end
end)

local var_0_111 = engine.get_netvar_offset("client.dll", "CBasePlayerController", "m_iDesiredFOV")

register_callback("paint", function()
	local var_32_0 = entitylist.get_local_player_controller()

	if var_32_0 then
		ffi.cast("int*", var_32_0[var_0_111])[0] = var_0_53.value
	end
end)
register_callback("paint", function()
	engine.execute_client_cmd("cam_idealdist " .. var_0_54.value)
end)

local var_0_112 = {
	def = 180,
	[67] = -90,
	[90] = 90
}
local var_0_113 = {}
local var_0_114 = var_0_112.def

register_callback("paint", function()
	if not var_0_44.value then
		return
	end

	for iter_34_0, iter_34_1 in pairs(var_0_112) do
		if iter_34_0 ~= "def" then
			local var_34_0 = var_0_72(iter_34_0)

			if var_34_0 ~= var_0_113[iter_34_0] and var_34_0 then
				var_0_114 = var_0_114 == iter_34_1 and var_0_112.def or iter_34_1
				menu.ragebot_anti_aim_base_yaw_offset = var_0_114
			end

			var_0_113[iter_34_0] = var_34_0
		end
	end
end)
register_callback("unload", function()
	menu.ragebot_anti_aim_base_yaw_offset = var_0_112.def
end)

local function var_0_115()
	if not var_0_57.value then
		return
	end

	local var_36_0 = 0
	local var_36_1 = 0
	local var_36_2 = render.screen_size()

	if var_0_114 == 90 then
		render.text("LEFT", var_0_28, vec2_t(25, var_36_2.y - 352), color_t(1, 1, 1, 1))
	end

	if var_0_114 == -90 then
		render.text("RIGHT", var_0_28, vec2_t(25, var_36_2.y - 352), color_t(1, 1, 1, 1))
	end
end

local var_0_116 = render.setup_font("C:/Windows/Fonts/verdana.ttf", 12, 8)
local var_0_117 = color_t(1, 1, 1, 1)
local var_0_118 = 0
local var_0_119 = os.clock()
local var_0_120 = 0

local function var_0_121()
	local var_37_0 = entitylist.get_local_player_controller()

	if var_37_0 == nil then
		return 0
	end

	return var_37_0.m_iPing
end

local function var_0_122()
	if not var_0_45.value then
		return
	end

	var_0_118 = var_0_118 + 1

	local var_38_0 = os.clock()

	if var_38_0 - var_0_119 >= 1 then
		var_0_120 = var_0_118
		var_0_119 = var_38_0
		var_0_118 = 0
	end

	local var_38_1 = entitylist.get_local_player_pawn()

	if var_38_1 == nil then
		return
	end

	local var_38_2 = var_38_1.m_pGameSceneNode

	if var_38_2 == nil then
		return
	end

	local var_38_3 = var_38_2.m_vecAbsOrigin

	if var_38_3 == nil then
		return
	end

	local var_38_4 = var_38_2.m_angRotation

	if var_38_4 == nil then
		return
	end

	local var_38_5 = var_38_3 + vec3_t(0, 0, 70)
	local var_38_6 = render.world_to_screen(var_38_5)

	if var_38_6 == nil then
		return
	end

	local var_38_7 = var_0_121()
	local var_38_8 = string.format("%d FPS %d PING", var_0_120, var_38_7)
	local var_38_9 = render.calc_text_size(var_38_8, var_0_116)
	local var_38_10 = math.rad(var_38_4.yaw)
	local var_38_11 = math.cos(var_38_10) * 50
	local var_38_12 = math.sin(var_38_10) * 50
	local var_38_13 = var_38_6 + vec2_t(var_38_11, var_38_12)

	render.text(var_38_8, var_0_116, var_38_13 - vec2_t(var_38_9.x / 2, 0), var_0_117)
end

local var_0_123 = ffi.cast("uintptr_t*(__fastcall*)(const char*)", find_pattern("client.dll", "40 55 48 83 EC 20 48 83"))
local var_0_124 = ffi.cast("void(__fastcall*)(uintptr_t)", find_pattern("client.dll", "48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 48 8B 71 68"))
local var_0_125 = false

local function var_0_126(arg_39_0)
	var_0_124(ffi.cast("uintptr_t", arg_39_0) - 40)

	var_0_125 = false
end

local function var_0_127(arg_40_0)
	local var_40_0 = var_0_123("CCSGO_HudDeathNotice")

	if not var_40_0 or var_40_0 == nil then
		return
	end

	ffi.cast("float*", ffi.cast("uintptr_t", var_40_0) + 80)[0] = arg_40_0 and 1.5 or 1e+20

	if var_0_125 then
		var_0_126(var_40_0)
	end
end

local function var_0_128()
	if var_0_60.value then
		var_0_127(false)
	else
		var_0_127(true)
	end
end

register_callback("paint", var_0_128)
register_callback("round_start", function(arg_42_0)
	if var_0_60.value then
		var_0_125 = true
	end
end)
register_callback("unload", function()
	var_0_125 = true

	var_0_127(true)
end)

local var_0_129 = color_t(0.8, 1, 0.2588235294117647, 1)
local var_0_130 = engine.get_netvar_offset("client.dll", "CCSPlayerController", "m_sSanitizedPlayerName")
local var_0_131 = engine.get_netvar_offset("client.dll", "C_CSPlayerPawnBase", "m_hOriginalController")
local var_0_132 = engine.get_netvar_offset("client.dll", "CBasePlayerController", "m_nTickBase")
local var_0_133 = render.setup_font("C:/Windows/Fonts/verdanab.ttf", 12, 16)
local var_0_134 = {}

local function var_0_135(arg_44_0, arg_44_1, arg_44_2)
	return arg_44_0 + (arg_44_1 - arg_44_0) * arg_44_2
end

local function var_0_136(arg_45_0)
	print("[gamesense] \x00", var_0_129)
	print(arg_45_0)
end

local function var_0_137(arg_46_0)
	if arg_46_0 == 1 then
		return "head"
	elseif arg_46_0 == 2 then
		return "chest"
	elseif arg_46_0 == 0 then
		return "generic"
	elseif arg_46_0 == 4 or arg_46_0 == 5 then
		return "arms"
	elseif arg_46_0 == 8 then
		return "neck"
	elseif arg_46_0 == 6 or arg_46_0 == 7 then
		return "legs"
	elseif arg_46_0 == 3 then
		return "stomach"
	else
		return "unknown"
	end
end

local function var_0_138(arg_47_0)
	if not var_0_46.value then
		return
	end

	if arg_47_0:get_pawn("attacker") ~= entitylist.get_local_player_pawn() then
		return
	end

	local var_47_0 = entitylist.get_local_player_controller()

	if not var_47_0 then
		return
	end

	local var_47_1 = ffi.cast("int*", var_47_0[var_0_132])[0]
	local var_47_2 = arg_47_0:get_controller("userid")

	if not var_47_2 then
		return
	end

	local var_47_3 = ffi.string(ffi.cast("char**", var_47_2[var_0_130])[0])
	local var_47_4 = arg_47_0:get_int("health")
	local var_47_5 = arg_47_0:get_int("dmg_health")
	local var_47_6 = arg_47_0:get_int("hitgroup")
	local var_47_7 = var_0_137(var_47_6)
	local var_47_8 = string.format("Hit %s in the %s for %d damage (%d health remaining)", var_47_3, var_47_7, var_47_5, var_47_4)

	var_0_136(var_47_8)
	table.insert(var_0_134, {
		szText = nil,
		flAlpha = 0,
		nTickBase = nil,
		szText = var_47_8,
		nTickBase = var_47_1 + 256
	})
end

local function var_0_139()
	if not var_0_46.value then
		return
	end

	local var_48_0 = entitylist.get_local_player_controller()

	if not var_48_0 then
		var_0_134 = {}

		return
	end

	local var_48_1 = ffi.cast("int*", var_48_0[var_0_132])[0]

	if not var_48_1 then
		return
	end

	local var_48_2 = 0

	for iter_48_0, iter_48_1 in ipairs(var_0_134) do
		local var_48_3 = vec2_t(5, 5 + var_48_2)
		local var_48_4 = var_0_129

		iter_48_1.flAlpha = var_0_135(iter_48_1.flAlpha, var_48_1 > iter_48_1.nTickBase and 0 or 1, 20 * render.frame_time())
		var_48_4.a = iter_48_1.flAlpha

		render.text("[gamesense]", var_0_133, var_48_3 + 1, color_t(0, 0, 0, iter_48_1.flAlpha * 0.25))
		render.text("[gamesense]", var_0_133, var_48_3, var_48_4)

		var_48_3.x = var_48_3.x + 80

		render.text(iter_48_1.szText, var_0_133, var_48_3 + 1, color_t(0, 0, 0, iter_48_1.flAlpha * 0.25))
		render.text(iter_48_1.szText, var_0_133, var_48_3, color_t(1, 1, 1, iter_48_1.flAlpha))

		var_48_2 = var_48_2 + 16 * iter_48_1.flAlpha

		if iter_48_1.flAlpha < 0.0001 then
			table.remove(var_0_134, iter_48_0)
		end
	end
end

local function var_0_140(arg_49_0, arg_49_1, arg_49_2)
	arg_49_0 = arg_49_0 + (arg_49_1 or 1)
	arg_49_0 = arg_49_0 + ffi.sizeof("int") + ffi.cast("int64_t", ffi.cast("int*", arg_49_0)[0])
	arg_49_0 = arg_49_0 + (arg_49_2 or 0)

	return arg_49_0
end

assert(ffi, "syr1337 hook lib error: ffi is not open, please open ffi")

if not pcall(ffi.sizeof, "struct Thread32Entry") then
	ffi.cdef("            typedef struct Thread32Entry {\n                uint32_t dwSize;\n                uint32_t cntUsage;\n                uint32_t th32ThreadID;\n                uint32_t th32OwnerProcessID;\n                long tpBasePri;\n                long tpDeltaPri;\n                uint32_t dwFlags;\n            } Thread32Entry;\n            \n            int CloseHandle(void*);\n            uint32_t ResumeThread(void*);\n            uint32_t GetCurrentThreadId();\n            uint32_t SuspendThread(void*);\n            uint32_t GetCurrentProcessId();\n            void* OpenThread(uint32_t, int, uint32_t);\n            void* GetProcAddress(uintptr_t, const char*);\n            int Thread32Next(void*, struct Thread32Entry*);\n            int Thread32First(void*, struct Thread32Entry*);\n            void* CreateToolhelp32Snapshot(uint32_t, uint32_t);\n            int VirtualProtect(void*, uint64_t, uint32_t, uint32_t*);\n        ")
end

local var_0_141 = render.screen_size() * 0.5
local var_0_142 = 0
local var_0_143 = engine.get_netvar_offset("client.dll", "C_CSPlayerPawn", "m_bIsScoped")
local var_0_144 = {}
local var_0_145 = {}
local var_0_146 = ffi.cast("void*", 0)
local var_0_147 = ffi.cast("void*", -1)
local var_0_148 = color_t(1, 1, 1, 1)
local var_0_149 = color_t(var_0_148.r, var_0_148.g, var_0_148.b, 0)
local var_0_150 = var_0_140(ffi.cast("uintptr_t", find_pattern("client.dll", "E8 ? ? ? ? 80 7C 24 ? ? 74 25")), 1, 0)

local function var_0_151(arg_50_0, arg_50_1, arg_50_2)
	return arg_50_0 + (arg_50_1 - arg_50_0) * arg_50_2
end

local function var_0_152(arg_51_0)
	local var_51_0 = ffi.C.OpenThread(2, 0, arg_51_0)

	if var_51_0 == var_0_146 or var_51_0 == var_0_147 then
		return false
	end

	return setmetatable({
		bValid = true,
		bIsSuspended = false,
		hThread = nil,
		nId = nil,
		nId = arg_51_0,
		hThread = var_51_0
	}, {
		__index = nil,
		__index = {
			Close = nil,
			Suspend = nil,
			Resume = nil,
			Suspend = function(arg_52_0)
				if arg_52_0.bIsSuspended or not arg_52_0.bValid then
					return false
				end

				if ffi.C.SuspendThread(arg_52_0.hThread) ~= -1 then
					arg_52_0.bIsSuspended = true

					return true
				end

				return false
			end,
			Resume = function(arg_53_0)
				if not arg_53_0.bIsSuspended or not arg_53_0.bValid then
					return false
				end

				if ffi.C.ResumeThread(arg_53_0.hThread) ~= -1 then
					arg_53_0.bIsSuspended = false

					return true
				end

				return false
			end,
			Close = function(arg_54_0)
				if not arg_54_0.bValid then
					return
				end

				arg_54_0:Resume()

				arg_54_0.bValid = false

				ffi.C.CloseHandle(arg_54_0.hThread)
			end
		}
	})
end

local function var_0_153()
	var_0_145 = {}

	local var_55_0 = ffi.C.CreateToolhelp32Snapshot(4, 0)

	if var_55_0 == var_0_147 then
		return false
	end

	local var_55_1 = ffi.new("struct Thread32Entry[1]")

	var_55_1[0].dwSize = ffi.sizeof("struct Thread32Entry")

	if ffi.C.Thread32First(var_55_0, var_55_1) == 0 then
		ffi.C.CloseHandle(var_55_0)

		return false
	end

	local var_55_2 = ffi.C.GetCurrentThreadId()
	local var_55_3 = ffi.C.GetCurrentProcessId()

	while ffi.C.Thread32Next(var_55_0, var_55_1) > 0 do
		if var_55_1[0].dwSize >= 20 and var_55_1[0].th32OwnerProcessID == var_55_3 and var_55_1[0].th32ThreadID ~= var_55_2 then
			local var_55_4 = var_0_152(var_55_1[0].th32ThreadID)

			if not var_55_4 then
				for iter_55_0, iter_55_1 in pairs(var_0_145) do
					iter_55_1:Close()
				end

				var_0_145 = {}

				ffi.C.CloseHandle(var_55_0)

				return false
			end

			table.insert(var_0_145, var_55_4)
		end
	end

	ffi.C.CloseHandle(var_55_0)

	return true
end

local function var_0_154()
	if not var_0_153() then
		return false
	end

	for iter_56_0, iter_56_1 in pairs(var_0_145) do
		iter_56_1:Suspend()
	end

	return true
end

local function var_0_155()
	for iter_57_0, iter_57_1 in pairs(var_0_145) do
		iter_57_1:Resume()
		iter_57_1:Close()
	end
end

local function var_0_156(arg_58_0, arg_58_1, arg_58_2)
	assert(type(arg_58_1) == "function", "syr1337 hook lib error: invalid detour function")
	assert(type(arg_58_0) == "cdata" or type(arg_58_0) == "number" or type(arg_58_0) == "function", "syr1337 hook lib error: invalid target function")

	if not var_0_154() then
		var_0_155()
		print("syr1337 hook lib error: failed suspend threads")

		return false
	end

	local var_58_0 = ffi.new("uint8_t[14]")
	local var_58_1 = ffi.cast(arg_58_2, arg_58_0)
	local var_58_2 = ffi.new("uint8_t[14]", {
		255,
		37,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	})
	local var_58_3 = {
		pTarget = nil,
		bValid = true,
		pOldProtect = nil,
		pBackup = nil,
		bAttached = false,
		pBackup = var_58_0,
		pTarget = var_58_1,
		pOldProtect = ffi.new("uint32_t[1]")
	}

	ffi.copy(var_58_0, var_58_1, ffi.sizeof(var_58_0))

	ffi.cast("uintptr_t*", var_58_2 + 6)[0] = ffi.cast("uintptr_t", ffi.cast(arg_58_2, function(...)
		local var_59_0, var_59_1 = pcall(arg_58_1, var_58_3, ...)

		if not var_59_0 then
			var_58_3:Remove()
			print(("[syr1337 hook lib]: unexception runtime error -> %s"):format(var_59_1))

			return var_58_1(...)
		end

		return var_59_1
	end))
	var_58_3.__index = setmetatable(var_58_3, {
		__index = nil,
		__call = nil,
		__call = function(arg_60_0, ...)
			if not arg_60_0.bValid then
				return nil
			end

			arg_60_0:Detach()

			local var_60_0, var_60_1 = pcall(arg_60_0.pTarget, ...)

			if not var_60_0 then
				arg_60_0.bValid = false

				print(("[syr1337 hook lib]: runtime error -> %s"):format(var_60_1))

				return nil
			end

			arg_60_0:Attach()

			return var_60_1
		end,
		__index = {
			Detach = nil,
			Remove = nil,
			Attach = nil,
			Attach = function(arg_61_0)
				if arg_61_0.bAttached or not arg_61_0.bValid then
					return false
				end

				arg_61_0.bAttached = true

				ffi.C.VirtualProtect(arg_61_0.pTarget, ffi.sizeof(var_58_0), 64, arg_61_0.pOldProtect)
				ffi.copy(arg_61_0.pTarget, var_58_2, ffi.sizeof(var_58_0))
				ffi.C.VirtualProtect(arg_61_0.pTarget, ffi.sizeof(var_58_0), arg_61_0.pOldProtect[0], arg_61_0.pOldProtect)

				return true
			end,
			Detach = function(arg_62_0)
				if not arg_62_0.bAttached or not arg_62_0.bValid then
					return false
				end

				arg_62_0.bAttached = false

				ffi.C.VirtualProtect(arg_62_0.pTarget, ffi.sizeof(var_58_0), 64, arg_62_0.pOldProtect)
				ffi.copy(arg_62_0.pTarget, arg_62_0.pBackup, ffi.sizeof(var_58_0))
				ffi.C.VirtualProtect(arg_62_0.pTarget, ffi.sizeof(var_58_0), arg_62_0.pOldProtect[0], arg_62_0.pOldProtect)

				return true
			end,
			Remove = function(arg_63_0)
				if not arg_63_0.bValid then
					return false
				end

				var_0_154()
				arg_63_0:Detach()
				var_0_155()

				arg_63_0.bValid = false
			end
		}
	})

	var_58_3:Attach()
	table.insert(var_0_144, var_58_3)
	var_0_155()

	return var_58_3
end

local var_0_157 = 10
local var_0_158 = 100
local var_0_159 = 1

register_callback("paint", function()
	var_0_157 = var_0_50.value
	var_0_158 = var_0_51.value
	var_0_159 = var_0_52.value
end)

local function var_0_160()
	local var_65_0 = entitylist.get_local_player_pawn()

	if var_65_0 == nil then
		return
	end

	if var_65_0.m_pGameSceneNode == nil then
		return
	end

	local var_65_1 = var_65_0.m_pWeaponServices

	if var_65_1 == nil then
		return
	end

	if var_65_1.m_hActiveWeapon == nil then
		return
	end

	if not var_0_49.value then
		return
	end

	local var_65_2 = ffi.cast("bool*", var_65_0[var_0_143])[0]
	local var_65_3 = color_t(var_0_148.r, var_0_148.g, var_0_148.b, var_0_148.a * var_0_159)
	local var_65_4 = color_t(var_0_149.r, var_0_149.g, var_0_149.b, var_0_149.a * var_0_159)

	if var_65_2 then
		local var_65_5 = var_0_157
		local var_65_6 = var_65_5 + var_0_158

		render.rect_filled_fade(vec2_t(var_0_141.x - var_65_5, var_0_141.y), vec2_t(var_0_141.x - var_65_6, var_0_141.y + 1), var_65_4, var_65_3, var_65_3, var_65_4)
		render.rect_filled_fade(vec2_t(var_0_141.x + var_65_6, var_0_141.y), vec2_t(var_0_141.x + var_65_5, var_0_141.y + 1), var_65_3, var_65_4, var_65_4, var_65_3)
		render.rect_filled_fade(vec2_t(var_0_141.x, var_0_141.y + var_65_6), vec2_t(var_0_141.x + 1, var_0_141.y + var_65_5), var_65_3, var_65_3, var_65_4, var_65_4)
		render.rect_filled_fade(vec2_t(var_0_141.x, var_0_141.y - var_65_5), vec2_t(var_0_141.x + 1, var_0_141.y - var_65_6), var_65_4, var_65_4, var_65_3, var_65_3)
	end
end

var_0_156(var_0_150, function(arg_66_0, arg_66_1, arg_66_2)
	return
end, "void(__fastcall*)(void*, void*)")
register_callback("paint", var_0_160)
register_callback("unload", function()
	for iter_67_0, iter_67_1 in pairs(var_0_144) do
		iter_67_1:Remove()
	end
end)
register_callback("paint", var_0_115)
register_callback("paint", var_0_139)
register_callback("player_hurt", var_0_138)
register_callback("paint", var_0_128)